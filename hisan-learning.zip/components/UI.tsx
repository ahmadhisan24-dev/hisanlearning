
import React from 'react';
import { COLORS } from '../constants';
import { UserRole } from '../types';

interface FeatureItemProps {
  icon: string;
  title: string;
  desc: string;
}

export const FeatureItem: React.FC<FeatureItemProps> = ({ icon, title, desc }) => (
  <div className="flex gap-4 items-start">
    <div className="size-10 bg-white rounded-xl flex items-center justify-center shrink-0 shadow-sm border border-emerald-100">
      <span className="material-symbols-outlined text-[#006400] text-xl">{icon}</span>
    </div>
    <div>
      <h4 className="text-sm font-bold text-slate-900 leading-tight">{title}</h4>
      <p className="text-[11px] text-slate-500 mt-1">{desc}</p>
    </div>
  </div>
);

interface InputFieldProps {
  icon: string;
  label: string;
  placeholder: string;
  value: string;
  onChange: (val: string) => void;
  type?: string;
}

export const InputField: React.FC<InputFieldProps> = ({ icon, label, placeholder, value, onChange, type = "text" }) => (
  <div className="flex flex-col gap-1.5 group text-left">
    <label className="text-slate-700 text-xs font-bold ml-1">{label}</label>
    <div className="relative">
      <span className="material-symbols-outlined absolute left-4 top-3.5 text-slate-400 text-xl group-focus-within:text-[#006400] transition-colors">{icon}</span>
      <input 
        type={type}
        className="w-full pl-12 pr-4 py-3.5 rounded-xl border-slate-200 bg-slate-50 focus:ring-2 focus:ring-[#006400] focus:border-[#006400] outline-none transition-all placeholder:text-slate-300 text-sm shadow-sm" 
        placeholder={placeholder} 
        value={value} 
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  </div>
);

interface RoleCardProps {
  title: string;
  icon: string;
  selected: boolean;
  onClick: () => void;
}

export const RoleCard: React.FC<RoleCardProps> = ({ title, icon, selected, onClick }) => (
  <button 
    type="button" 
    onClick={onClick}
    className={`flex flex-col items-center justify-center p-4 border-2 rounded-2xl transition-all gap-2 ${selected ? 'border-[#006400] bg-[#006400]/5 text-[#006400]' : 'border-slate-100 bg-white text-slate-400'}`}
  >
    <span className="material-symbols-outlined text-2xl">{icon}</span>
    <span className="text-[11px] font-bold">{title}</span>
  </button>
);

interface StatCardProps {
  icon: string;
  label: string;
  val: string | number;
  color: 'green' | 'gold';
}

export const StatCard: React.FC<StatCardProps> = ({ icon, label, val, color }) => {
  const isGreen = color === 'green';
  return (
    <div className="bg-white p-5 rounded-[2.5rem] shadow-sm border border-slate-50 flex flex-col gap-1 text-left">
      <div className={`size-10 rounded-2xl flex items-center justify-center mb-2 ${isGreen ? 'bg-[#006400]/10 text-[#006400]' : 'bg-[#D4AF37]/10 text-[#D4AF37]'}`}>
        <span className="material-symbols-outlined">{icon}</span>
      </div>
      <p className="text-slate-400 text-[9px] font-bold uppercase tracking-wider">{label}</p>
      <p className="text-2xl font-bold text-slate-900">{val}</p>
    </div>
  );
};

interface TrackCardProps {
  title: string;
  desc: string;
  progress?: number;
  status: string;
  img: string;
  locked?: boolean;
  onClick: () => void;
  isManagementMode?: boolean;
}

export const TrackCard: React.FC<TrackCardProps> = ({ title, desc, progress = 0, status, img, locked, onClick, isManagementMode }) => (
  <div onClick={!locked ? onClick : undefined} className={`bg-white rounded-3xl overflow-hidden shadow-md border border-slate-100 transition-all active:scale-[0.98] ${locked ? 'opacity-60 cursor-not-allowed' : 'cursor-pointer'} text-left`}>
    <div className="h-32 bg-cover bg-center relative" style={{ backgroundImage: `url(${img})` }}>
      <div className="absolute inset-0 bg-black/40"></div>
      <div className={`absolute top-3 right-3 text-[8px] font-bold px-3 py-1 rounded-full ${locked ? 'bg-slate-200 text-slate-500' : 'bg-[#D4AF37] text-white'}`}>{status}</div>
    </div>
    <div className="p-5">
      <h3 className="font-bold text-base mb-1 truncate">{title}</h3>
      <p className="text-slate-500 text-[11px] mb-4 line-clamp-2">{desc}</p>
      {!isManagementMode ? (
        <div className="space-y-1">
          <div className="flex justify-between text-[10px] font-bold text-[#006400]"><span>Progres</span><span>{progress}%</span></div>
          <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden shadow-inner">
            <div className="bg-[#006400] h-full transition-all duration-700" style={{ width: `${progress}%` }}></div>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 text-[10px] font-bold text-[#006400]">
           <span className="material-symbols-outlined text-sm">settings</span>
           <span>Kelola Konten & Kurikulum</span>
        </div>
      )}
    </div>
  </div>
);

interface ActivityItemProps {
  title: string;
  type: string;
  completed?: boolean;
  current?: boolean;
  locked?: boolean;
  isManagementMode?: boolean;
  onDelete?: () => void;
}

export const ActivityItem: React.FC<ActivityItemProps> = ({ title, type, completed, current, locked, isManagementMode, onDelete }) => {
  const icon = type.includes('Kuis') ? 'quiz' : type.includes('Video') ? 'play_circle' : 'description';
  return (
    <div className={`p-5 rounded-2xl border flex gap-4 transition-all text-left ${current ? 'border-[#006400] bg-green-50/20' : 'border-slate-50'} ${locked ? 'opacity-50' : ''}`}>
      <div className={`size-11 rounded-xl flex items-center justify-center shrink-0 ${completed ? 'bg-green-100 text-green-600' : current ? 'bg-[#006400] text-white shadow-lg' : 'bg-slate-50 text-slate-400'}`}>
        <span className="material-symbols-outlined">{icon}</span>
      </div>
      <div className="flex-1 min-w-0">
        <h4 className={`font-bold text-sm truncate ${locked ? 'text-slate-400' : 'text-slate-900'}`}>{title}</h4>
        <p className="text-[10px] text-slate-500 mt-1 font-medium uppercase tracking-wider">{type}</p>
      </div>
      {isManagementMode && (
        <button onClick={onDelete} className="text-slate-300 hover:text-red-500 transition-colors">
            <span className="material-symbols-outlined text-lg">delete</span>
        </button>
      )}
    </div>
  );
};

interface UserActionCardProps {
    name: string;
    role: UserRole;
    nip: string;
    onReset: () => void;
    onDelete: () => void;
    onRoleChange: (newRole: UserRole) => void;
}

export const UserActionCard: React.FC<UserActionCardProps> = ({ name, role, nip, onReset, onDelete, onRoleChange }) => {
  const roleColors = {
    'Admin': 'text-purple-600 bg-purple-50',
    'Teacher': 'text-blue-600 bg-blue-50',
    'Siswa': 'text-emerald-600 bg-emerald-50'
  };

  return (
    <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col gap-3 text-left">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
              <div className="size-10 rounded-full bg-slate-100 flex items-center justify-center shrink-0 overflow-hidden">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`} alt="avatar" />
              </div>
              <div className="min-w-0">
                  <p className="text-xs font-bold text-slate-900 truncate">{name}</p>
                  <p className="text-[9px] text-slate-400 truncate uppercase font-bold tracking-tight">{nip}</p>
              </div>
          </div>
          <div className="flex gap-1 shrink-0">
              <button onClick={onReset} className="size-8 flex items-center justify-center rounded-lg bg-emerald-50 text-emerald-600 hover:bg-emerald-100" title="Reset Password">
                  <span className="material-symbols-outlined text-lg">lock_reset</span>
              </button>
              <button onClick={onDelete} className="size-8 flex items-center justify-center rounded-lg bg-red-50 text-red-600 hover:bg-red-100" title="Hapus User">
                  <span className="material-symbols-outlined text-lg">delete</span>
              </button>
          </div>
        </div>
        
        <div className="flex items-center justify-between border-t border-slate-50 pt-2 mt-1">
          <div className={`px-2 py-1 rounded-md text-[9px] font-bold uppercase tracking-wider ${roleColors[role]}`}>
            {role === 'Teacher' ? 'Guru' : role}
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-400 uppercase">Peran:</span>
            <select 
              value={role} 
              onChange={(e) => onRoleChange(e.target.value as UserRole)}
              className="text-[10px] font-bold bg-slate-50 border border-slate-200 rounded-lg px-2 py-1 outline-none text-[#006400]"
            >
              <option value="Siswa">Siswa</option>
              <option value="Teacher">Guru</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
        </div>
    </div>
  );
};

interface LeaderboardItemProps {
  rank: number;
  name: string;
  unit: string;
  pts: string | number;
  active?: boolean;
}

export const LeaderboardItem: React.FC<LeaderboardItemProps> = ({ rank, name, unit, pts, active }) => (
  <div className={`flex items-center gap-4 px-4 py-3 rounded-xl text-left ${active ? 'bg-[#006400]/5 border border-[#006400]/10' : ''}`}>
    <div className="w-6 shrink-0 flex items-center justify-center font-bold text-slate-400 text-xs">
      {rank === 1 ? "🥇" : rank === 2 ? "🥈" : rank === 3 ? "🥉" : `#${rank}`}
    </div>
    <div className="flex items-center gap-3 flex-1 min-w-0">
      <div className="size-9 rounded-full bg-slate-200 overflow-hidden shrink-0 border-2 border-white">
         <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`} alt="avatar" />
      </div>
      <div className="flex flex-col min-w-0">
        <p className="text-slate-900 text-xs font-bold leading-tight truncate">{name}</p>
        <p className="text-slate-400 text-[9px] truncate">{unit}</p>
      </div>
    </div>
    <div className="text-right shrink-0">
      <p className="text-xs font-bold text-[#006400]">{pts}</p>
      <p className="text-[8px] uppercase font-bold text-slate-400">PTS</p>
    </div>
  </div>
);

interface BottomNavProps {
  currentPage: string;
  navigateTo: (page: any) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ currentPage, navigateTo }) => {
  const items = [
    { id: 'dashboard', icon: 'home', label: 'Home' },
    { id: 'paths', icon: 'explore', label: 'Jalur' },
    { id: 'module', icon: 'menu_book', label: 'Belajar' },
    { id: 'profile', icon: 'account_circle', label: 'Profil' },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[480px] h-20 bg-white/95 backdrop-blur-md border-t flex items-center justify-around px-4 z-40 shadow-[0_-5px_15px_rgba(0,0,0,0.05)]">
      {items.map((item) => (
        <button key={item.id} onClick={() => navigateTo(item.id)} className={`flex flex-col items-center gap-1 transition-colors ${currentPage === item.id ? 'text-[#006400]' : 'text-slate-400'}`}>
          <span className={`material-symbols-outlined ${currentPage === item.id ? 'fill-1' : ''}`}>{item.icon}</span>
          <span className="text-[9px] font-bold tracking-tighter uppercase">{item.label}</span>
        </button>
      ))}
    </nav>
  );
};
