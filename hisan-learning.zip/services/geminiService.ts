
import { GoogleGenAI, Type } from "@google/genai";
import { QuestionType } from "../types";

export const generateQuizQuestions = async (
  topic: string, 
  types: QuestionType[], 
  customPrompt: string = ""
) => {
  try {
    // Initialize AI inside the function to ensure process.env.API_KEY is available at runtime
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
    
    const typesStr = types.join(", ");
    const prompt = `Buatkan total 5-10 soal kuis tentang topik: "${topic}".
    Jenis soal yang diminta adalah campuran dari: ${typesStr}.
    
    Instruksi Tambahan dari User: "${customPrompt || 'Tidak ada instruksi khusus'}"
    
    Aturan Format:
    1. Jika Pilihan Ganda: Berikan 4 opsi (A, B, C, D).
    2. Jika Benar/Salah: Opsi harus berisi "Benar" dan "Salah".
    3. Jika Isian Singkat: Berikan kunci jawaban yang singkat dan padat.
    
    Pastikan proporsi soal seimbang antara jenis yang dipilih. Format dalam Bahasa Indonesia.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "Daftar opsi jawaban. Kosongkan jika Isian Singkat."
              },
              answer: { type: Type.STRING },
              type: { type: Type.STRING, description: "Jenis soal (Pilihan Ganda, Benar/Salah, atau Isian Singkat)" }
            },
            required: ["question", "options", "answer", "type"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) return [];

    // Clean potential markdown formatting from JSON response
    const cleanedText = text.replace(/```json|```/g, "").trim();
    return JSON.parse(cleanedText);
  } catch (error) {
    console.error("Error generating quiz:", error);
    return null;
  }
};
